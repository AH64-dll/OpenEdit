# OpenEdit: Put your ideas in motion

Ten seconds, 1920x1080, 60 fps. Original motion graphics and stereo audio.

Extract this folder into your OpenEdit projects folder (normally ~/OpenEditProjects).
Use the current OpenEdit build, including the rich-animation node-budget fix.
Start OpenEdit, select this project, and choose Graphics to scrub or edit its layers.
The main timeline holds V1 graphics, A1 music, and A2 sound effects. Use Export
for a new video. Keep the complete .open_edit directory when saving or moving it.
Rendered caches are omitted and OpenEdit generates them when needed.

The saved graphics document is openedit-explainer and its timeline clip is explainer.
Audio stays editable on separate music and sound-effects clips. Saved revision: 5.
Standalone scene.jsx is a source copy; the database owns the actual edit history.
See the repository's examples/openedit-explainer for the original asset generator,
stems, source, and workflow evidence. Artwork and audio are MIT; font is OFL.
